class UserNamesEnum:
    Jake = "jacob_adam_weldon"
    Luke = "weldonla"
    Nat = "GnatOnTheWall"
    James = "soManyFeathers"