class Token:
    token = '5278136330:AAF6xs9AY2-FjzdIa-ua4jo0ZqmPuZ0N-mo'