class ChoreStatusEnum:
    INCOMPLETE = "INCOMPLETE"
    COMPLETE = "COMPLETE"
    SNOOZE = "SNOOZE"